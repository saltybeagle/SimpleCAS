<?php
class SimpleCAS_ProxyGranting_Storage_File implements SimpleCAS_ProxyGranting_Storage
{
    function saveIOU($iou)
    {
        throw new Exception('not implemented');
    }
    
    function getProxyGrantingTicket($iou)
    {
        throw new Exception('not implemented');
    }
}